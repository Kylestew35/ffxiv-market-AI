import json
import boto3

bedrock = boto3.client("bedrock-runtime")

def handler(event, context):
    body = json.loads(event.get("body", "{}"))
    question = body.get("question", "")

    if not question:
        return _response(400, {"error": "Missing question"})

    prompt = f"""
You are an FFXIV marketboard expert. Answer the user's question clearly and concisely.

User question:
{question}
"""

    ai_res = bedrock.invoke_model(
        modelId="anthropic.claude-3-haiku-20240307",
        body=json.dumps({
            "max_tokens": 300,
            "messages": [
                {"role": "user", "content": prompt}
            ]
        })
    )

    ai_text = json.loads(ai_res["body"].read())["content"][0]["text"]

    return _response(200, {"answer": ai_text})


def _response(status, body):
    return {
        "statusCode": status,
        "headers": {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*"
        },
        "body": json.dumps(body)
    }
