# backend/config.py

S3_BUCKET = "ffxiv-data-bucket"
ITEMS_KEY = "data/items.json"

UNIVERSALIS_BASE_URL = "https://universalis.app/api/v2"
# Optional: simple thresholds for recommendations
PRICE_DIFF_TRAVEL_THRESHOLD = 0.3  # 30%
HIGH_PRICE_MULTIPLIER = 1.6
