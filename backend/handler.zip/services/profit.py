# backend/services/profit.py

from typing import List, Dict, Any
from .universalis import get_market_data

# For now, you can hardcode or predefine a list of item IDs per job/level.
# Later, you can derive this from your S3 datasets.
PROFIT_ITEM_IDS = {
    "botanist": [  # example IDs
        12345,  # Spruce Log
        67890,  # Example item
    ]
}

def find_profitable_items(
    job: str,
    level: int,
    world: str,
    items_index: Dict[int, Dict[str, Any]],
) -> List[Dict[str, Any]]:
    ids = PROFIT_ITEM_IDS.get(job.lower(), [])
    results = []

    for item_id in ids:
        item = items_index.get(item_id)
        if not item:
            continue

        market = get_market_data(world, item_id)
        listings = market.get("listings", [])
        if not listings:
            continue

        min_price = min(l["pricePerUnit"] for l in listings)
        results.append({
            "itemId": item_id,
            "name": item.get("Name_en"),
            "minPrice": min_price,
            "numListings": len(listings),
        })

    # Sort by price descending for now
    results.sort(key=lambda x: x["minPrice"], reverse=True)
    return results
