# backend/services/universalis.py

import requests
from typing import Dict, Any
from config import UNIVERSALIS_BASE_URL

def get_market_data(world: str, item_id: int) -> Dict[str, Any]:
    url = f"{UNIVERSALIS_BASE_URL}/{world}/{item_id}"
    resp = requests.get(url, timeout=5)
    resp.raise_for_status()
    return resp.json()
