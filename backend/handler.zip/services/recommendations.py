# backend/services/recommendations.py

from typing import Dict, Any
from config import PRICE_DIFF_TRAVEL_THRESHOLD

def summarize_market(market: Dict[str, Any]) -> Dict[str, Any]:
    # Universalis v2 aggregated data: minPriceNQ, minPriceHQ, etc.
    # We’ll be defensive and fall back if keys are missing.
    listings = market.get("listings", [])
    nq_prices = [l["pricePerUnit"] for l in listings if not l.get("hq")]
    hq_prices = [l["pricePerUnit"] for l in listings if l.get("hq")]

    min_nq = min(nq_prices) if nq_prices else None
    min_hq = min(hq_prices) if hq_prices else None

    return {
        "minNQ": min_nq,
        "minHQ": min_hq,
        "worldName": market.get("worldName"),
        "dcName": market.get("dcName"),
        "lastUploadTime": market.get("lastUploadTime"),
        "numListings": len(listings),
    }

def build_recommendations(
    current_world: str,
    item: Dict[str, Any],
    market: Dict[str, Any],
    dc_market: Dict[str, Any] | None = None,
) -> Dict[str, Any]:
    current_summary = summarize_market(market)
    dc_summary = summarize_market(dc_market) if dc_market else None

    options = []

    # Option: stay on current world
    options.append({
        "id": "stay",
        "label": "Buy on your current world",
        "world": current_world,
        "minNQ": current_summary["minNQ"],
        "minHQ": current_summary["minHQ"],
        "reason": "Lowest friction, no travel required.",
    })

    # Option: travel to cheaper world in DC
    if dc_summary and dc_summary["minNQ"] and current_summary["minNQ"]:
        diff = (current_summary["minNQ"] - dc_summary["minNQ"]) / current_summary["minNQ"]
        if diff >= PRICE_DIFF_TRAVEL_THRESHOLD:
            options.append({
                "id": "travel",
                "label": "Travel to another world in your data center",
                "world": dc_summary["worldName"],
                "minNQ": dc_summary["minNQ"],
                "minHQ": dc_summary["minHQ"],
                "reason": f"Cheaper by ~{int(diff * 100)}% compared to your world.",
            })

    # Option: craft it yourself (simple heuristic)
    options.append({
        "id": "craft",
        "label": "Craft or gather it yourself",
        "reason": "Prices are high or demand is strong—consider crafting/gathering for profit.",
    })

    return {
        "item": {
            "id": item["ID"],
            "name": item.get("Name_en"),
        },
        "currentWorld": current_world,
        "marketSummary": current_summary,
        "options": options,
    }
