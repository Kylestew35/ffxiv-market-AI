# backend/services/s3_items.py

import json
import boto3
from typing import List, Dict
from config import S3_BUCKET, ITEMS_KEY

_s3 = boto3.client("s3")
_items_cache: List[Dict] | None = None

def load_items() -> List[Dict]:
    global _items_cache
    if _items_cache is not None:
        return _items_cache

    obj = _s3.get_object(Bucket=S3_BUCKET, Key=ITEMS_KEY)
    data = obj["Body"].read().decode("utf-8")
    _items_cache = json.loads(data)
    return _items_cache

def search_items(query: str, limit: int = 50) -> List[Dict]:
    items = load_items()
    q = query.lower()
    results = [
        item for item in items
        if q in item.get("Name_en", "").lower()
    ]
    return results[:limit]
